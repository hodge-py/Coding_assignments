<html>
<body>

<form action="welcome.php" method="post">
Department Name: <input type="text" name="dept_name"><br>
Building: <input type="text" name="building"><br>
Budget: <input type = "number" name = "budget"><br>
<input type="submit">
</form>

</body>
</html>